-- ============================================================
-- Zolyn — Row Level Security Policies
-- This file is the real security boundary of the app.
-- Every school-scoped table is locked to auth.uid()'s
-- membership. Super admins bypass via is_super_admin().
-- ============================================================

-- ------------------------------------------------------------
-- super_admins: only readable/writable by super admins themselves
-- ------------------------------------------------------------
alter table super_admins enable row level security;

create policy "super_admins_self_select"
on super_admins for select
using ( id = auth.uid() or is_super_admin() );

-- (inserts into super_admins are done manually via SQL editor by you,
-- never via the app — no insert policy for normal users)

-- ------------------------------------------------------------
-- schools
-- ------------------------------------------------------------
alter table schools enable row level security;

-- Anyone authenticated can see basic school info (needed for "join school" search)
-- but only active/approved schools are visible to non-members.
create policy "schools_public_read"
on schools for select
using (
  status = 'active'
  or is_super_admin()
  or is_active_member(id)
  or created_by = auth.uid()
);

-- Any authenticated user can register a new school (becomes school_admin via trigger)
create policy "schools_insert_self"
on schools for insert
with check ( created_by = auth.uid() );

-- Only the school's own school_admin, or super admin, can update it
create policy "schools_update_admin"
on schools for update
using (
  is_super_admin()
  or member_role(id) = 'school_admin'
);

-- Only super admin can change status (approve/suspend) — enforced additionally at app layer
create policy "schools_super_admin_all"
on schools for all
using ( is_super_admin() );

-- ------------------------------------------------------------
-- subscriptions
-- ------------------------------------------------------------
alter table subscriptions enable row level security;

create policy "subscriptions_school_read"
on subscriptions for select
using ( is_super_admin() or is_active_member(school_id) );

create policy "subscriptions_super_admin_write"
on subscriptions for all
using ( is_super_admin() );

-- ------------------------------------------------------------
-- user_profiles: every authenticated user manages their own row
-- ------------------------------------------------------------
alter table user_profiles enable row level security;

create policy "user_profiles_self"
on user_profiles for all
using ( id = auth.uid() or is_super_admin() )
with check ( id = auth.uid() );

-- ------------------------------------------------------------
-- school_members — the core access-control table
-- ------------------------------------------------------------
alter table school_members enable row level security;

-- Members can see other members of their own school (needed for staff lists)
create policy "school_members_read"
on school_members for select
using (
  is_super_admin()
  or user_id = auth.uid()
  or is_active_member(school_id)
);

-- A user can create their own initial school_admin row when registering a school
-- (handled by trigger, see 0004) — no direct insert policy needed for that path.
-- Admin-tier users can add teacher_admins directly (invite flow), teachers come
-- in via school_membership_requests instead.
create policy "school_members_insert_by_admin_tier"
on school_members for insert
with check (
  is_super_admin()
  or is_school_admin_tier(school_id)
);

-- Update/removal: school_admin can update anyone; teacher_admin can update
-- anyone EXCEPT rows where role = 'school_admin'. This is the rule that
-- guarantees a teacher_admin can never demote/remove a school_admin.
create policy "school_members_update_hierarchy"
on school_members for update
using (
  is_super_admin()
  or member_role(school_id) = 'school_admin'
  or (member_role(school_id) = 'teacher_admin' and role <> 'school_admin')
);

-- ------------------------------------------------------------
-- school_membership_requests
-- ------------------------------------------------------------
alter table school_membership_requests enable row level security;

-- A user can see their own requests; admin-tier can see requests for their school
create policy "membership_requests_read"
on school_membership_requests for select
using (
  is_super_admin()
  or user_id = auth.uid()
  or is_school_admin_tier(school_id)
);

-- Any authenticated user can request to join a school
create policy "membership_requests_insert_self"
on school_membership_requests for insert
with check ( user_id = auth.uid() );

-- Only admin-tier can approve/reject (update status)
create policy "membership_requests_review"
on school_membership_requests for update
using ( is_super_admin() or is_school_admin_tier(school_id) );

-- ------------------------------------------------------------
-- Generic pattern for all remaining school-scoped tables:
-- SELECT/INSERT/UPDATE/DELETE gated on active membership,
-- with extra permission checks per table for writes.
-- ------------------------------------------------------------

-- academic_sessions
alter table academic_sessions enable row level security;

create policy "academic_sessions_read"
on academic_sessions for select
using ( is_super_admin() or is_active_member(school_id) );

create policy "academic_sessions_write"
on academic_sessions for all
using ( is_super_admin() or is_school_admin_tier(school_id) );

-- grade_scales
alter table grade_scales enable row level security;

create policy "grade_scales_read"
on grade_scales for select
using ( is_super_admin() or is_active_member(school_id) );

create policy "grade_scales_write"
on grade_scales for all
using ( is_super_admin() or is_school_admin_tier(school_id) );

-- classes
alter table classes enable row level security;

create policy "classes_read"
on classes for select
using ( is_super_admin() or is_active_member(school_id) );

create policy "classes_write"
on classes for all
using ( is_super_admin() or has_permission(school_id, 'manage_classes') );

-- subjects
alter table subjects enable row level security;

create policy "subjects_read"
on subjects for select
using ( is_super_admin() or is_active_member(school_id) );

create policy "subjects_write"
on subjects for all
using ( is_super_admin() or has_permission(school_id, 'manage_subjects') );

-- teacher_subject_class
alter table teacher_subject_class enable row level security;

create policy "tsc_read"
on teacher_subject_class for select
using ( is_super_admin() or is_active_member(school_id) );

create policy "tsc_write"
on teacher_subject_class for all
using ( is_super_admin() or is_school_admin_tier(school_id) );

-- students
alter table students enable row level security;

create policy "students_read"
on students for select
using ( is_super_admin() or is_active_member(school_id) );

create policy "students_write"
on students for all
using ( is_super_admin() or has_permission(school_id, 'manage_students') );

-- attendance
alter table attendance enable row level security;

create policy "attendance_read"
on attendance for select
using ( is_super_admin() or is_active_member(school_id) );

-- Teachers can record attendance for classes they are assigned to; admin-tier
-- with manage_attendance permission can record/edit any class's attendance.
create policy "attendance_write"
on attendance for all
using (
  is_super_admin()
  or has_permission(school_id, 'manage_attendance')
  or exists (
    select 1 from teacher_subject_class tsc
    where tsc.school_id = attendance.school_id
      and tsc.class_id = attendance.class_id
      and tsc.teacher_id = auth.uid()
  )
);

-- results
alter table results enable row level security;

create policy "results_read"
on results for select
using ( is_super_admin() or is_active_member(school_id) );

-- Teachers can enter/edit their own draft scores for subjects/classes assigned to them.
-- Admin-tier with enter_results/approve_results permission can do more (e.g. approve).
create policy "results_write"
on results for all
using (
  is_super_admin()
  or has_permission(school_id, 'approve_results')
  or (
    has_permission(school_id, 'enter_results')
    and entered_by = auth.uid()
  )
  or exists (
    select 1 from teacher_subject_class tsc
    where tsc.school_id = results.school_id
      and tsc.subject_id = results.subject_id
      and tsc.teacher_id = auth.uid()
  )
);

-- report_cards
alter table report_cards enable row level security;

create policy "report_cards_read"
on report_cards for select
using ( is_super_admin() or is_active_member(school_id) );

create policy "report_cards_write"
on report_cards for all
using ( is_super_admin() or has_permission(school_id, 'generate_report_cards') );

-- notifications
alter table notifications enable row level security;

-- Platform-wide notifications (school_id null) visible to everyone authenticated.
-- School-scoped notifications visible only to that school's active members.
create policy "notifications_read"
on notifications for select
using (
  school_id is null
  or is_super_admin()
  or is_active_member(school_id)
);

create policy "notifications_write"
on notifications for insert
with check (
  is_super_admin()
  or (school_id is not null and is_school_admin_tier(school_id))
);
