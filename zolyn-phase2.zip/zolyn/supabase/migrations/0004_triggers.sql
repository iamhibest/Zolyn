-- ============================================================
-- Zolyn — Triggers
-- 1. Auto-create user_profiles row when someone signs up
-- 2. Auto-create an active school_admin membership when a
--    user registers a new school
-- ============================================================

-- ------------------------------------------------------------
-- 1. New auth user -> user_profiles row
-- ------------------------------------------------------------
create or replace function handle_new_user()
returns trigger
language plpgsql
security definer
as $$
begin
  insert into public.user_profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- ------------------------------------------------------------
-- 2. New school -> creator becomes active school_admin immediately
--    (school itself still needs Super Admin approval to go 'active',
--    but the creator can manage it in pending state)
-- ------------------------------------------------------------
create or replace function handle_new_school()
returns trigger
language plpgsql
security definer
as $$
begin
  insert into public.school_members (school_id, user_id, role, status, created_by)
  values (new.id, new.created_by, 'school_admin', 'active', new.created_by);
  return new;
end;
$$;

drop trigger if exists on_school_created on schools;
create trigger on_school_created
  after insert on schools
  for each row execute function handle_new_school();

-- ------------------------------------------------------------
-- 3. Approving a school_membership_request -> creates the
--    active school_members row for that teacher
-- ------------------------------------------------------------
create or replace function handle_membership_approval()
returns trigger
language plpgsql
security definer
as $$
begin
  if new.status = 'approved' and old.status = 'pending' then
    insert into public.school_members (school_id, user_id, role, status, created_by)
    values (new.school_id, new.user_id, 'teacher', 'active', new.reviewed_by)
    on conflict (school_id, user_id) do update
      set status = 'active', role = 'teacher', updated_at = now();

    new.reviewed_at = now();
  elsif new.status = 'rejected' and old.status = 'pending' then
    new.reviewed_at = now();
  end if;
  return new;
end;
$$;

drop trigger if exists on_membership_request_reviewed on school_membership_requests;
create trigger on_membership_request_reviewed
  before update on school_membership_requests
  for each row execute function handle_membership_approval();
