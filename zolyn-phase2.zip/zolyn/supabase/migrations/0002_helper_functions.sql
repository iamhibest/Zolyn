-- ============================================================
-- Zolyn — Helper functions used by RLS policies
-- Defined as SECURITY DEFINER + STABLE so they bypass RLS
-- internally and don't cause recursive policy evaluation.
-- ============================================================

-- Is the current user a super admin?
create or replace function is_super_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from super_admins where id = auth.uid()
  );
$$;

-- Is the current user an active member of a given school?
create or replace function is_active_member(target_school_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from school_members
    where school_id = target_school_id
      and user_id = auth.uid()
      and status = 'active'
  );
$$;

-- What role does the current user hold at a given school? (null if none/not active)
create or replace function member_role(target_school_id uuid)
returns text
language sql
security definer
stable
as $$
  select role from school_members
  where school_id = target_school_id
    and user_id = auth.uid()
    and status = 'active'
  limit 1;
$$;

-- Does the current user hold admin-tier access (school_admin or teacher_admin) at a school?
create or replace function is_school_admin_tier(target_school_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from school_members
    where school_id = target_school_id
      and user_id = auth.uid()
      and status = 'active'
      and role in ('school_admin','teacher_admin')
  );
$$;

-- Does the current user have a specific permission key set true
-- (school_admin always has all permissions implicitly)
create or replace function has_permission(target_school_id uuid, perm_key text)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from school_members
    where school_id = target_school_id
      and user_id = auth.uid()
      and status = 'active'
      and (
        role = 'school_admin'
        or (permissions ->> perm_key)::boolean is true
      )
  );
$$;
