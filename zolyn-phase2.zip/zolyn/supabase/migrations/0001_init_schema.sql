-- ============================================================
-- Zolyn — Phase 1: Core Schema
-- Platform, schools, membership, academic structure
-- ============================================================

create extension if not exists "pgcrypto";

-- ============================================================
-- PLATFORM LEVEL
-- ============================================================

create table super_admins (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz default now()
);

create table schools (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text,
  phone text,
  logo_url text,
  status text not null default 'pending_approval'
    check (status in ('pending_approval','active','suspended')),
  subscription_status text not null default 'trial'
    check (subscription_status in ('trial','active','expired')),
  current_period_start date,
  current_period_end date,
  created_by uuid references auth.users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  amount numeric not null,
  period_start date not null,
  period_end date not null,
  status text not null default 'pending_payment'
    check (status in ('pending_payment','paid','expired')),
  paystack_reference text,
  paystack_verified boolean default false,
  paid_at timestamptz,
  created_at timestamptz default now()
);

-- ============================================================
-- USERS & MEMBERSHIP
-- ============================================================

create table user_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  avatar_url text,
  created_at timestamptz default now()
);

create table school_members (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('school_admin','teacher_admin','teacher')),
  status text not null default 'pending'
    check (status in ('pending','active','rejected','removed')),
  permissions jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  removed_by uuid references auth.users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (school_id, user_id)
);

-- request to join an existing school (before school_admin approval)
create table school_membership_requests (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  requested_role text not null default 'teacher' check (requested_role in ('teacher')),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  reviewed_by uuid references auth.users(id),
  created_at timestamptz default now(),
  reviewed_at timestamptz
);

-- ============================================================
-- ACADEMIC STRUCTURE
-- ============================================================

create table academic_sessions (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  name text not null,          -- "2025/2026"
  term text not null,          -- "First Term"
  is_current boolean default false,
  created_at timestamptz default now()
);

create table grade_scales (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  grade_label text not null,   -- "A", "B1", etc.
  min_score numeric not null,
  max_score numeric not null,
  remark text,
  created_at timestamptz default now()
);

create table classes (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  name text not null,
  class_teacher_id uuid references auth.users(id),
  created_at timestamptz default now()
);

create table subjects (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  name text not null,
  created_at timestamptz default now()
);

create table teacher_subject_class (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  teacher_id uuid not null references auth.users(id),
  subject_id uuid not null references subjects(id) on delete cascade,
  class_id uuid not null references classes(id) on delete cascade,
  created_at timestamptz default now(),
  unique (teacher_id, subject_id, class_id)
);

-- ============================================================
-- STUDENTS, ATTENDANCE, RESULTS, REPORT CARDS
-- ============================================================

create table students (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  full_name text not null,
  admission_no text,
  class_id uuid references classes(id),
  passport_url text,
  guardian_name text,
  guardian_phone text,
  guardian_email text,
  status text not null default 'active' check (status in ('active','graduated','withdrawn')),
  created_at timestamptz default now()
);

create table attendance (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  class_id uuid not null references classes(id),
  date date not null,
  status text not null check (status in ('present','absent','late')),
  marked_by uuid references auth.users(id),
  created_at timestamptz default now(),
  unique (student_id, date)
);

create table results (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  subject_id uuid not null references subjects(id) on delete cascade,
  session_id uuid not null references academic_sessions(id) on delete cascade,
  ca_score numeric not null default 0,
  exam_score numeric not null default 0,
  total_score numeric generated always as (ca_score + exam_score) stored,
  grade text,
  entered_by uuid references auth.users(id),
  approved_by uuid references auth.users(id),
  status text not null default 'draft' check (status in ('draft','submitted','approved')),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (student_id, subject_id, session_id)
);

create table report_cards (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references schools(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  session_id uuid not null references academic_sessions(id) on delete cascade,
  position integer,
  total_score numeric,
  average numeric,
  teacher_remark text,
  principal_remark text,
  attendance_summary jsonb,
  generated_at timestamptz default now(),
  unique (student_id, session_id)
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

create table notifications (
  id uuid primary key default gen_random_uuid(),
  school_id uuid references schools(id) on delete cascade,  -- null = platform-wide
  title text not null,
  message text not null,
  target_role text,   -- 'all','teachers','admins', null = everyone incl. guests
  created_by uuid references auth.users(id),
  created_at timestamptz default now()
);

-- ============================================================
-- INDEXES for common lookups
-- ============================================================

create index idx_school_members_user on school_members(user_id);
create index idx_school_members_school on school_members(school_id);
create index idx_students_school on students(school_id);
create index idx_students_class on students(class_id);
create index idx_results_student_session on results(student_id, session_id);
create index idx_attendance_student_date on attendance(student_id, date);
create index idx_membership_requests_school on school_membership_requests(school_id, status);
